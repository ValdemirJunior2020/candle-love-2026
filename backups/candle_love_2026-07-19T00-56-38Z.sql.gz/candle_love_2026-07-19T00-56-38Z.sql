--
-- PostgreSQL database dump
--

\restrict skeeJo5gZSKtngLvBQt5iiImmKRD0trf1XDL7RHOgd8bcD57zKigfTFxq728lwJ

-- Dumped from database version 17.10
-- Dumped by pg_dump version 17.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: app_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.app_migrations (
    name text NOT NULL,
    applied_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: blocks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.blocks (
    blocker_id uuid NOT NULL,
    blocked_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT blocks_check CHECK ((blocker_id <> blocked_id))
);


--
-- Name: conversations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.conversations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    match_id uuid NOT NULL,
    free_message_limit smallint DEFAULT 6 NOT NULL,
    unlocked_at timestamp with time zone,
    unlocked_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT conversations_free_message_limit_check CHECK (((free_message_limit >= 0) AND (free_message_limit <= 20)))
);


--
-- Name: gifts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gifts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    slug text NOT NULL,
    name text NOT NULL,
    cost integer NOT NULL,
    image_path text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT gifts_cost_check CHECK ((cost > 0))
);


--
-- Name: matches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.matches (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_a uuid NOT NULL,
    user_b uuid NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT matches_check CHECK (((user_a)::text < (user_b)::text))
);


--
-- Name: messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    conversation_id uuid NOT NULL,
    sender_id uuid NOT NULL,
    content text DEFAULT ''::text NOT NULL,
    gift_id uuid,
    moderation jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT messages_check CHECK (((char_length(TRIM(BOTH FROM content)) > 0) OR (gift_id IS NOT NULL))),
    CONSTRAINT messages_content_check CHECK ((char_length(content) <= 1500))
);


--
-- Name: profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.profiles (
    user_id uuid NOT NULL,
    bio text DEFAULT ''::text NOT NULL,
    city text DEFAULT ''::text NOT NULL,
    photo_url text,
    intentions text DEFAULT 'relationship'::text NOT NULL,
    interests text[] DEFAULT '{}'::text[] NOT NULL,
    prompt_answer text DEFAULT ''::text NOT NULL,
    profile_complete boolean DEFAULT false NOT NULL,
    last_active_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT profiles_bio_check CHECK ((char_length(bio) <= 500)),
    CONSTRAINT profiles_intentions_check CHECK ((intentions = ANY (ARRAY['relationship'::text, 'friendship'::text, 'unsure'::text])))
);


--
-- Name: refresh_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.refresh_sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    token_hash text NOT NULL,
    user_agent text,
    ip_hash text,
    expires_at timestamp with time zone NOT NULL,
    revoked_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reports (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    reporter_id uuid NOT NULL,
    reported_id uuid NOT NULL,
    conversation_id uuid,
    category text NOT NULL,
    details text DEFAULT ''::text NOT NULL,
    status text DEFAULT 'open'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT reports_category_check CHECK ((category = ANY (ARRAY['harassment'::text, 'hate'::text, 'sexual'::text, 'scam'::text, 'impersonation'::text, 'underage'::text, 'other'::text]))),
    CONSTRAINT reports_check CHECK ((reporter_id <> reported_id)),
    CONSTRAINT reports_details_check CHECK ((char_length(details) <= 1000)),
    CONSTRAINT reports_status_check CHECK ((status = ANY (ARRAY['open'::text, 'reviewing'::text, 'resolved'::text, 'dismissed'::text])))
);


--
-- Name: swipes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.swipes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    actor_id uuid NOT NULL,
    target_id uuid NOT NULL,
    decision text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT swipes_check CHECK ((actor_id <> target_id)),
    CONSTRAINT swipes_decision_check CHECK ((decision = ANY (ARRAY['pass'::text, 'spark'::text, 'super_spark'::text])))
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email public.citext NOT NULL,
    password_hash text NOT NULL,
    display_name text NOT NULL,
    birth_date date NOT NULL,
    verified boolean DEFAULT false NOT NULL,
    trust_level smallint DEFAULT 0 NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT users_display_name_check CHECK (((char_length(display_name) >= 2) AND (char_length(display_name) <= 50))),
    CONSTRAINT users_status_check CHECK ((status = ANY (ARRAY['active'::text, 'paused'::text, 'suspended'::text, 'deleted'::text]))),
    CONSTRAINT users_trust_level_check CHECK (((trust_level >= 0) AND (trust_level <= 3)))
);


--
-- Name: wallet_ledger; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wallet_ledger (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    amount integer NOT NULL,
    reason text NOT NULL,
    reference_id text,
    idempotency_key text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT wallet_ledger_amount_check CHECK ((amount <> 0))
);


--
-- Name: wallets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wallets (
    user_id uuid NOT NULL,
    balance integer DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT wallets_balance_check CHECK ((balance >= 0))
);


--
-- Data for Name: app_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.app_migrations (name, applied_at) FROM stdin;
001_init.sql	2026-07-18 23:13:51.038143+00
\.


--
-- Data for Name: blocks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.blocks (blocker_id, blocked_id, created_at) FROM stdin;
\.


--
-- Data for Name: conversations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.conversations (id, match_id, free_message_limit, unlocked_at, unlocked_by, created_at) FROM stdin;
\.


--
-- Data for Name: gifts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gifts (id, slug, name, cost, image_path, active, created_at) FROM stdin;
e264bdfc-15f2-422c-a412-3d549ee6c54d	royal-panda	Royal Panda	5	/gifts/royal-panda.png	t	2026-07-18 23:15:26.972405+00
3a25a4b7-8647-4587-8464-f20f352bfd27	crystal-heart	Crystal Heart	8	/gifts/crystal-heart.png	t	2026-07-18 23:15:26.980361+00
576ef41b-d102-4c71-b097-452412a42205	love-bot	Love Bot	10	/gifts/love-bot.png	t	2026-07-18 23:15:26.985704+00
b4e1a219-96bb-4152-bd82-40b6ee3f9c26	cozy-mushroom	Cozy Mushroom	12	/gifts/cozy-mushroom.png	t	2026-07-18 23:15:26.99007+00
764beacb-1802-4ad7-b1fd-34b53a22a7c6	sky-date	Sky Date	18	/gifts/sky-date.png	t	2026-07-18 23:15:26.994047+00
\.


--
-- Data for Name: matches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.matches (id, user_a, user_b, active, created_at) FROM stdin;
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.messages (id, conversation_id, sender_id, content, gift_id, moderation, created_at) FROM stdin;
\.


--
-- Data for Name: profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.profiles (user_id, bio, city, photo_url, intentions, interests, prompt_answer, profile_complete, last_active_at) FROM stdin;
cf5d4432-a95f-450c-ab5f-b14a411e491c			\N	relationship	{}		f	2026-07-18 23:29:57.497074+00
52e6ea29-60aa-441c-becf-2702a18f905a	Lover of cozy evenings, deep conversation, and finding that spark.	Miami	/profiles/maya.png	relationship	{"Book Club","Wine Tasting",Photography}	Kindness is the fastest way to my heart.	t	2026-07-18 23:15:26.934944+00
647e30c2-0e30-4f0f-91be-840c418047f3	Coffee walks, live music, and thoughtful conversations.	Fort Lauderdale	\N	relationship	{Music,Coffee,Travel}	Kindness is the fastest way to my heart.	t	2026-07-18 23:15:26.958482+00
502d300c-5343-4360-8343-35f8e94d2b4a	Building a peaceful life and looking for someone kind to share it with.	Boca Raton	\N	relationship	{Cooking,Beach,Art}	Kindness is the fastest way to my heart.	t	2026-07-18 23:15:26.96552+00
28607c14-1ab4-4a29-966b-07abf31e8d9a			\N	relationship	{}		f	2026-07-18 23:56:43.927005+00
\.


--
-- Data for Name: refresh_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.refresh_sessions (id, user_id, token_hash, user_agent, ip_hash, expires_at, revoked_at, created_at) FROM stdin;
ec8df572-8dcf-40a2-b5b1-13c44e469a4b	cf5d4432-a95f-450c-ab5f-b14a411e491c	715ab66901d8d55aeca25b540740b3228750cccf516179211daef241e2072948	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	79f1ed7c3831720253675dcf97a9714711e3e0ec94b6abf77f5bbf0280dc9c0d	2026-08-17 23:29:57.554+00	2026-07-18 23:36:50.249799+00	2026-07-18 23:29:57.554789+00
4d40fc96-1791-4a10-aa06-86ca1fd1b71b	28607c14-1ab4-4a29-966b-07abf31e8d9a	9b55faa0fc9ad462e00147afba25d100a49da689903247a8811b16a81022e251	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	79f1ed7c3831720253675dcf97a9714711e3e0ec94b6abf77f5bbf0280dc9c0d	2026-08-17 23:56:43.953+00	2026-07-19 00:02:41.453711+00	2026-07-18 23:56:43.953692+00
1f7ce99e-c52d-4b3f-b80c-0123e5694b5a	28607c14-1ab4-4a29-966b-07abf31e8d9a	babac6617857a191b402403a900fc3f305831bc8e4148c15fc0d71e051cf8868	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36	79f1ed7c3831720253675dcf97a9714711e3e0ec94b6abf77f5bbf0280dc9c0d	2026-08-18 00:02:41.465+00	\N	2026-07-19 00:02:41.465354+00
\.


--
-- Data for Name: reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reports (id, reporter_id, reported_id, conversation_id, category, details, status, created_at) FROM stdin;
\.


--
-- Data for Name: swipes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.swipes (id, actor_id, target_id, decision, created_at) FROM stdin;
a7a6c526-0cc1-40d8-a7b1-f4b4ce123cb1	cf5d4432-a95f-450c-ab5f-b14a411e491c	502d300c-5343-4360-8343-35f8e94d2b4a	pass	2026-07-18 23:30:05.648086+00
30535427-1fa4-4363-8cc0-7ddb5034a391	cf5d4432-a95f-450c-ab5f-b14a411e491c	647e30c2-0e30-4f0f-91be-840c418047f3	spark	2026-07-18 23:30:07.981047+00
a18a3aa2-68c6-4f6a-98eb-b7cb74a66328	cf5d4432-a95f-450c-ab5f-b14a411e491c	52e6ea29-60aa-441c-becf-2702a18f905a	super_spark	2026-07-18 23:30:10.836881+00
4a0fbb96-82c4-4eac-aa2e-22c347944c20	28607c14-1ab4-4a29-966b-07abf31e8d9a	502d300c-5343-4360-8343-35f8e94d2b4a	spark	2026-07-18 23:56:50.700438+00
2593d997-105e-44e8-a5dd-11d9d9507faa	28607c14-1ab4-4a29-966b-07abf31e8d9a	647e30c2-0e30-4f0f-91be-840c418047f3	super_spark	2026-07-18 23:56:54.120734+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, password_hash, display_name, birth_date, verified, trust_level, status, created_at, updated_at) FROM stdin;
cf5d4432-a95f-450c-ab5f-b14a411e491c	infojr.8@gmail.com	scrypt$cd30f47472ecc203823d399b933eff7b$027977afc07806a6ba3de3f08b3dbe5a334d06a2b6a9b343ccedd6d59b87fc6beb3c720fd6aa2e5f6b94c1734da25598487e9c318597a82288d9c622b0b3af09	Valdemir	1983-12-05	f	0	active	2026-07-18 23:29:57.497074+00	2026-07-18 23:29:57.497074+00
52e6ea29-60aa-441c-becf-2702a18f905a	maya@example.com	scrypt$2696e3ceba02d17a7eab4ce5513e1be8$6a2fe5d6bf89b77bcbac5dcc0488656ea0cb24670c981bb08929551df8b2a6bf823b14b91d0bec982909cf64914eaea9b5f5979b6328e173c4547fbccca0a2e2	Maya	1998-05-12	t	2	active	2026-07-18 23:15:26.934944+00	2026-07-18 23:15:26.934944+00
647e30c2-0e30-4f0f-91be-840c418047f3	jordan@example.com	scrypt$2696e3ceba02d17a7eab4ce5513e1be8$6a2fe5d6bf89b77bcbac5dcc0488656ea0cb24670c981bb08929551df8b2a6bf823b14b91d0bec982909cf64914eaea9b5f5979b6328e173c4547fbccca0a2e2	Jordan	1995-11-03	t	2	active	2026-07-18 23:15:26.958482+00	2026-07-18 23:15:26.958482+00
502d300c-5343-4360-8343-35f8e94d2b4a	sofia@example.com	scrypt$2696e3ceba02d17a7eab4ce5513e1be8$6a2fe5d6bf89b77bcbac5dcc0488656ea0cb24670c981bb08929551df8b2a6bf823b14b91d0bec982909cf64914eaea9b5f5979b6328e173c4547fbccca0a2e2	Sofia	1997-02-22	t	2	active	2026-07-18 23:15:26.96552+00	2026-07-18 23:15:26.96552+00
28607c14-1ab4-4a29-966b-07abf31e8d9a	testing@test.com	scrypt$079b4b6402fdc9a0393148f9b104411b$ae5efebf7cf88b2ce3d6e6941b0193d9f9cc22ac480514af6f2b068e56c295355634397e3a90e85751b165fb36ce450fdea280699c3bfd1f4ec2836c80ea402e	testing	1982-01-12	f	0	active	2026-07-18 23:56:43.927005+00	2026-07-18 23:56:43.927005+00
\.


--
-- Data for Name: wallet_ledger; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.wallet_ledger (id, user_id, amount, reason, reference_id, idempotency_key, created_at) FROM stdin;
9af55544-d257-42a1-a693-97144cd0dc3c	cf5d4432-a95f-450c-ab5f-b14a411e491c	25	starter_sparks	\N	\N	2026-07-18 23:29:57.497074+00
90811ef3-7d0c-4bb2-9c79-7f1b01b137c1	cf5d4432-a95f-450c-ab5f-b14a411e491c	-5	super_spark	52e6ea29-60aa-441c-becf-2702a18f905a	\N	2026-07-18 23:30:10.836881+00
b73b4acc-7f9b-4bd6-825e-57052088f1a2	28607c14-1ab4-4a29-966b-07abf31e8d9a	25	starter_sparks	\N	\N	2026-07-18 23:56:43.927005+00
4fa560e9-8ae1-4b74-9ab5-adf4d9567fd3	28607c14-1ab4-4a29-966b-07abf31e8d9a	-5	super_spark	647e30c2-0e30-4f0f-91be-840c418047f3	\N	2026-07-18 23:56:54.120734+00
\.


--
-- Data for Name: wallets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.wallets (user_id, balance, updated_at) FROM stdin;
52e6ea29-60aa-441c-becf-2702a18f905a	100	2026-07-18 23:15:26.934944+00
647e30c2-0e30-4f0f-91be-840c418047f3	100	2026-07-18 23:15:26.958482+00
502d300c-5343-4360-8343-35f8e94d2b4a	100	2026-07-18 23:15:26.96552+00
cf5d4432-a95f-450c-ab5f-b14a411e491c	20	2026-07-18 23:30:10.836881+00
28607c14-1ab4-4a29-966b-07abf31e8d9a	20	2026-07-18 23:56:54.120734+00
\.


--
-- Name: app_migrations app_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_migrations
    ADD CONSTRAINT app_migrations_pkey PRIMARY KEY (name);


--
-- Name: blocks blocks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blocks
    ADD CONSTRAINT blocks_pkey PRIMARY KEY (blocker_id, blocked_id);


--
-- Name: conversations conversations_match_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_match_id_key UNIQUE (match_id);


--
-- Name: conversations conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_pkey PRIMARY KEY (id);


--
-- Name: gifts gifts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gifts
    ADD CONSTRAINT gifts_pkey PRIMARY KEY (id);


--
-- Name: gifts gifts_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gifts
    ADD CONSTRAINT gifts_slug_key UNIQUE (slug);


--
-- Name: matches matches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matches
    ADD CONSTRAINT matches_pkey PRIMARY KEY (id);


--
-- Name: matches matches_user_a_user_b_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matches
    ADD CONSTRAINT matches_user_a_user_b_key UNIQUE (user_a, user_b);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_pkey PRIMARY KEY (user_id);


--
-- Name: refresh_sessions refresh_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_sessions
    ADD CONSTRAINT refresh_sessions_pkey PRIMARY KEY (id);


--
-- Name: refresh_sessions refresh_sessions_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_sessions
    ADD CONSTRAINT refresh_sessions_token_hash_key UNIQUE (token_hash);


--
-- Name: reports reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_pkey PRIMARY KEY (id);


--
-- Name: swipes swipes_actor_id_target_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.swipes
    ADD CONSTRAINT swipes_actor_id_target_id_key UNIQUE (actor_id, target_id);


--
-- Name: swipes swipes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.swipes
    ADD CONSTRAINT swipes_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: wallet_ledger wallet_ledger_idempotency_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wallet_ledger
    ADD CONSTRAINT wallet_ledger_idempotency_key_key UNIQUE (idempotency_key);


--
-- Name: wallet_ledger wallet_ledger_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wallet_ledger
    ADD CONSTRAINT wallet_ledger_pkey PRIMARY KEY (id);


--
-- Name: wallets wallets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wallets
    ADD CONSTRAINT wallets_pkey PRIMARY KEY (user_id);


--
-- Name: idx_matches_users; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_matches_users ON public.matches USING btree (user_a, user_b) WHERE (active = true);


--
-- Name: idx_messages_conversation; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_messages_conversation ON public.messages USING btree (conversation_id, created_at);


--
-- Name: idx_profiles_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_profiles_active ON public.profiles USING btree (last_active_at DESC);


--
-- Name: idx_refresh_sessions_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_refresh_sessions_user ON public.refresh_sessions USING btree (user_id, expires_at);


--
-- Name: idx_reports_open; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_reports_open ON public.reports USING btree (status, created_at);


--
-- Name: idx_swipes_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_swipes_target ON public.swipes USING btree (target_id, decision);


--
-- Name: blocks blocks_blocked_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blocks
    ADD CONSTRAINT blocks_blocked_id_fkey FOREIGN KEY (blocked_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: blocks blocks_blocker_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.blocks
    ADD CONSTRAINT blocks_blocker_id_fkey FOREIGN KEY (blocker_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: conversations conversations_match_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_match_id_fkey FOREIGN KEY (match_id) REFERENCES public.matches(id) ON DELETE CASCADE;


--
-- Name: conversations conversations_unlocked_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_unlocked_by_fkey FOREIGN KEY (unlocked_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: matches matches_user_a_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matches
    ADD CONSTRAINT matches_user_a_fkey FOREIGN KEY (user_a) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: matches matches_user_b_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matches
    ADD CONSTRAINT matches_user_b_fkey FOREIGN KEY (user_b) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: messages messages_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON DELETE CASCADE;


--
-- Name: messages messages_gift_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_gift_id_fkey FOREIGN KEY (gift_id) REFERENCES public.gifts(id) ON DELETE SET NULL;


--
-- Name: messages messages_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: profiles profiles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: refresh_sessions refresh_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_sessions
    ADD CONSTRAINT refresh_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: reports reports_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON DELETE SET NULL;


--
-- Name: reports reports_reported_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_reported_id_fkey FOREIGN KEY (reported_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: reports reports_reporter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_reporter_id_fkey FOREIGN KEY (reporter_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: swipes swipes_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.swipes
    ADD CONSTRAINT swipes_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: swipes swipes_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.swipes
    ADD CONSTRAINT swipes_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: wallet_ledger wallet_ledger_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wallet_ledger
    ADD CONSTRAINT wallet_ledger_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: wallets wallets_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wallets
    ADD CONSTRAINT wallets_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict skeeJo5gZSKtngLvBQt5iiImmKRD0trf1XDL7RHOgd8bcD57zKigfTFxq728lwJ

